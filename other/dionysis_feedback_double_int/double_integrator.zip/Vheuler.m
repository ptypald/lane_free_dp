function [t,x,y,w,v,acc,accy,Ht]=Vheuler(h,t_final,x,y,w,v,Atol,Rtol,model)


global   vstar n p  mu2 vmax mu1 A phi a c L lambda   q  rho epsilon visc wmax


% t_vec=0:h:t_final;
%
 
 

 
 
% F = zeros(n,1);
% u = zeros(n,1);
% K = zeros(n,1);
t=0;

 
x_Heun=x;
y_Heun=y;
w_Heun=w;
v_Heun=v;

j = 1;

dis = zeros(n);
Vdot = zeros(n); 
t(1) = 0;
z = 1;
vk1(n) = 0; vk2(n) = 0;
wk1(n) = 0; wk2 = 0;
xk1(n) = 0; xk2(n) = 0;
yk1(n) = 0; yk2(n) = 0;
 H(1)=h; 
 
 
while t(z) <= t_final
    err = 0;
    error = 0;
    vk1 = 0; vk2 = 0;
    wk1 = 0; wk2 = 0;
    xk1 = 0; xk2 = 0;
    yk1 = 0; yk2 = 0;
    for i = 1 : n
        V1(i)=0;
        V2(i)=0;
        viscx(i)=0;
        viscy(i)=0;
        for j = 1 : n
            if i ~= j
                dis(i,j) = dist(x_Heun(z,i), x_Heun(z,j), y_Heun(z,i), y_Heun(z,j), p);
                Vdot(i,j) = Vd(dis(i,j),  L,lambda, q);
                V1(i) = V1(i) + Vdot(i,j)*(x_Heun(z,i) - x_Heun(z,j))/dis(i,j);
                V2(i) = V2(i) + Vdot(i,j)*(y_Heun(z,i) - y_Heun(z,j))/dis(i,j);
                if visc~=0
                    viscx(i)=viscx(i)+kappa(dis(i,j),L,lambda,visc)*(g1(v_Heun(z,j))-g1(v_Heun(z,i)));
                    viscy(i)=viscy(i)+kappa(dis(i,j),L,lambda,visc)*(g2(w_Heun(z,j))-g2(w_Heun(z,i)));
                end
            end
        end
        %%
        if model == 1
            Lambdai = -V1(i) + viscx(i);
            Gi =  Ud(y_Heun(z,i), a, c) + p*V2(i) - viscy(i);
            Li = mu2 + 1/(mu2*wmax)*Gi^2;
            k = mu1 + (Lambdai /vstar)+(vmax / (vstar * (vmax - vstar))) * f(-Lambdai, epsilon);
            F = - k * (v_Heun(z,i) - vstar) + Lambdai;
            u = - Li*w_Heun(z,i) - Gi;
            
        else
            qC = (vmax*v_Heun(z,i)*cos(w_Heun(z,i))+vstar*vmax-2*vstar*v_Heun(z,i))/(2*(vmax-v_Heun(z,i))^2*v_Heun(z,i)^2);
            betaC = A/((cos(w_Heun(z,i))-cos(phi))^2)+((rho-1)*v_Heun(z,i)*cos(w_Heun(z,i))+vstar)/(vmax-v_Heun(z,i));
            aC = rho*vmax*sin(w_Heun(z,i))/(2*(vmax-v_Heun(z,i))^2*v_Heun(z,i));
            F  = 1/qC*(viscx(i)-mu2*(v_Heun(z,i)*cos(w_Heun(z,i))-vstar)-V1(i));
            u  =  v_Heun(z,i)/betaC*(viscy(i)-mu1*v_Heun(z,i)*sin(w_Heun(z,i))-Ud(y_Heun(z,i),a,c)- aC*F-p*V2(i));
        end
        %%
                        
        acc(z,i) = F;
        accy(z,i) = u;
        
        vk1(i) = h*(F);
        wk1(i) = h*(u);
        yk1(i) = h*(w_Heun(z,i));
        xk1(i) = h*(v_Heun(z,i));
        
        v_temp(i) = v_Heun(z,i) + vk1(i);
        w_temp(i) = w_Heun(z,i) + wk1(i);
        y_temp(i) = y_Heun(z,i) + yk1(i);
        x_temp(i) = x_Heun(z,i) + xk1(i);
    end
    
    for i = 1 : n
        
        V1(i)=0;
        V2(i)=0;
        viscx(i)=0;
        viscy(i)=0;
        for j = 1 : n
            if i ~= j
                dis(i,j) = dist(x_temp(i) , x_Heun(z,j) + xk1(j), y_temp(i), y_Heun(z,j) + yk1(j), p);
                Vdot(i,j) = Vd(dis(i,j), L, lambda,  q);
                V1(i) = V1(i) + Vdot(i,j)*(x_temp(i) - x_Heun(z,j) - xk1(j))/dis(i,j);
                V2(i) = V2(i) + Vdot(i,j)*(y_temp(i) - y_Heun(z,j) - yk1(j))/dis(i,j);  
                if visc ~=0
                    viscx(i)=viscx(i)+kappa(dis(i,j),L,lambda,visc)*(g1(v_Heun(z,j)+vk1(j))-g1(v_Heun(z,i)+vk1(i)));
                    viscy(i)=viscy(i)+kappa(dis(i,j),L,lambda,visc)*(g2(w_Heun(z,j)+wk1(j))-g2(w_Heun(z,i)+wk1(i)));
                end
            end
        end
        %%
        if model == 1
            Lambdai = -V1(i) + viscx(i);
            Gi =  Ud(y_Heun(z,i)+yk1(i), a, c) + p*V2(i) - viscy(i);
            Li = mu2 + 1/(mu2*wmax)*Gi^2;
            k = mu1 + (Lambdai /vstar)+(vmax / (vstar * (vmax - vstar))) * f(-Lambdai, epsilon);
            F = - k * (v_Heun(z,i)+vk1(i) - vstar) + Lambdai;
            u = - Li*(w_Heun(z,i)+wk1(i)) - Gi;
        else
            qC = (vmax*(v_Heun(z,i)+vk1(i))*cos(w_Heun(z,i)+wk1(i))+vstar*vmax-2*vstar*(v_Heun(z,i)+vk1(i)))/(2*(vmax-(v_Heun(z,i)+vk1(i)))^2*(v_Heun(z,i)+vk1(i))^2);
            betaC = A/((cos(w_Heun(z,i)+wk1(i))-cos(phi))^2)+((rho-1)*(v_Heun(z,i)+vk1(i))*cos(w_Heun(z,i)+wk1(i))+vstar)/(vmax-(v_Heun(z,i)+vk1(i)));
            aC = rho*vmax*sin(w_Heun(z,i)+wk1(i))/(2*(vmax-(v_Heun(z,i)+vk1(i)))^2*(v_Heun(z,i)+vk1(i)));
            F  = 1/qC*(viscx(i)-mu2*((v_Heun(z,i)+vk1(i))*cos(w_Heun(z,i)+wk1(i))-vstar)-V1(i));
            u  =  (v_Heun(z,i)+vk1(i))/betaC*(viscy(i)-mu1*(v_Heun(z,i)+vk1(i))*sin(w_Heun(z,i)+wk1(i))-Ud(y_Heun(z,i)+yk1(i),a,c)- aC*F-p*V2(i));
        end
        %%
        
        vk2(i) = h*(F);
        wk2(i) = h*(u);
        yk2(i) = h*(w_temp(i));
        xk2(i) = h*(v_temp(i));
        

        %%
        v_Heun(z+1,i) = v_Heun(z,i) + (0.5)*(vk1(i) + vk2(i));
        w_Heun(z+1,i) = w_Heun(z,i) + (0.5)*(wk1(i) + wk2(i));
        y_Heun(z+1,i) = y_Heun(z,i) + (0.5)*(yk1(i) + yk2(i));
        x_Heun(z+1,i) = x_Heun(z,i) + (0.5)*(xk1(i) + xk2(i));
        
        %%
        sc_x(i) = Atol + Rtol*max(abs(x_Heun(z+1,i)), abs(x_Heun(z,i)));
        sc_y(i) = Atol + Rtol*max(abs(y_Heun(z+1,i)), abs(y_Heun(z,i)));
        sc_w(i) = Atol + Rtol*max(abs(w_Heun(z+1,i)), abs(w_Heun(z,i)));
        sc_v(i) = Atol + Rtol*max(abs(v_Heun(z+1,i)), abs(v_Heun(z,i)));
        
        err(i) = sqrt(0.25*((x_temp(i) - x_Heun(z+1,i))/sc_x(i))^2 + 0.25*((y_temp(i) - y_Heun(z+1,i))/sc_y(i))^2 + 0.25*((v_temp(i) - v_Heun(z+1,i))/sc_v(i))^2 + 0.25*((w_temp(i) - w_Heun(z+1,i))/sc_w(i))^2);
        %-----------------------------%
        if i == n
            error = max(err());
            if error <= 1
                z = z + 1;
                h = h*min(2, 0.8*sqrt(1/error));
                %   fprintf('flag1\n');
                t(z) = t(z-1) + h;
            elseif error > 1
                %  fprintf('flag2\n');
                h = h*min(2, 0.8*sqrt(1/error));
            end
        end
    end
    %-------------------------------%
    
    %           if h>0.3
    %               h=0.01;
    %           end
%      
%     if t(z) + h > t_final
%         h = t_final - t(z);
%     
%     end

    Ht(z)=h;

    %      if h>=1
    %          h=1;
    %      end
    
    
    
    %H(j+1)=h;
    
    
end
x=transpose(x_Heun);
w=transpose(w_Heun);
y=transpose(y_Heun);
v=transpose(v_Heun);
acc=transpose(acc);
accy=transpose(accy);
end
%     if h<1.5
%         if mod(j*0.1,100)==0
%             h=h*1.2;
%         end
%     else
%         h=1.5;
%     end
%     t(j + 1) = t(j) + h;
%     t(j)
%      j= j+1;
%    % t(j)


%  x(i,j+1) = x(i,j) +0.5*h*(k11+k12);
%         y(i,j+1) = y(i,j) +0.5*h*(k21+k22);
%         theta(i,j+1)= theta(i,j) +0.5*h*(k31+k32);
%         v(i,j+1) = v(i,j) +0.5*h*(k41+k42);

%%% CHECK VALUES OF  VISC
% 
% xPR=xPR';
% yPR=yPR';
% thetaPR=thetaPR';
% vPR=vPR';
% 
% for z=1:2829
%     for i = 1 : n
%         for j=1:n
%             if i ~= j
%                 dis(i,j) = dist(xPR(z,i), xPR(z,j), yPR(z,i), yPR(z,j), p);
%                 testx(z,i)=testx(z,i)+kappa(dis(i,j),L,lambda)*(g1(vPR(z,j)*cos(thetaPR(z,j)))-g1(vPR(z,i)*cos(thetaPR(z,i))));
%                 testy(z,i)=testy(z,i)+kappa(dis(i,j),L,lambda)*(g2(vPR(z,j)*sin(thetaPR(z,j)))-g2(vPR(z,i)*sin(thetaPR(z,i))));
%               testqx(z,i)=1/((vmax*vPR(z,i)*cos(thetaPR(z,i))+vstar*vmax-2*vstar*vPR(z,i))/(2*(vmax-vPR(z,i))^2*vPR(z,i)^2))*testx(z,i);
%             end
%         end
%     end
% end
%  