% clear
% clearvars -except x y v w
clearvars -except x y v w t2 acc accy xPR yPR vPR wPR t1 accPR accyPR xN yN wN vN accN

global  a vmax vstar sigma n q  L lambda mu2 mu1 epsilon A c p phi rho visc wmax

h=0.01;
n=10;
A = 1;
a=7.2;
vmax=35;
wmax =   8.6591;
vstar=30;

L = 5.59;

lambda = 25;
sigma = 5;

p=5.11;
rho=1;
c = 1.5;
epsilon = 0.2;

%t=0;

t_final=100;
 

Atol=1*10^(-4 );
Rtol=1*10^(-4);


% NEWTONIAN
model =1;
visc=0.0;
q=10^(-3);
mu1 = 0.05;
mu2 =10.5;

% RELATIVISTIC
% model =0; 
% visc=0;% 0.3*1/vmax^2;
% q=10^(-3)/vmax^1;
% mu1 = 0.5;
% mu2 =1/vmax^2;
 

%  X0=x;
%  Y0=y;
%  V0=v;
%  T0=w;
%3
% V0=[25.0000 32.0000 26.0000];
% X0=[1.0000 15.0000 40.0000];
% T0=[0.02 0.08 -0.08];
% Y0=[-3.2565 2.7614 -0.7773];

 % 10
X0 =[3, 17.9348, 18.5025, 32.7845, 48.8248, 67.4112, 76.7717, 85.3403, 99.5535, 109.47];
V0 =[34, 33.0623, 32.9935, 28.728, 33.5955, 29.2333, 33.2551, 27.8382, 29.6052, 26.7413];
T0 =[-0.051, -0.0074182, 0, -0.00169008, 0.0192594, 0.0099249, -0.0133584, -0.024981, -0.00739978, -0.0217153];
Y0 =[2, -5.8796, 5.21576, 0.1683, 3.27928, -3.2841, 5.99578, -1.07857, 3.08981, -1.63232];
%  

% 
% X0=[3, 16.1146, 29.9583, 43.2069, 56.3986, 69.4482, 82.2764, 95.8763, 109.345, 122.835, 135.97, 148.704, 161.739, 175.343, 188.046];
% V0=[14, 12.8833, 19.2267, 11.2041, 17.6637, 13.5103, 17.8634, 14.8497, 13.7693, 15.7123, 18.2286, 16.3488, 17.3802, 11.6599, 19.3026];
% T0=[-0.1, 0.0847284, -0.0973689, 0.0369971, 0.0510635, -0.0139028, -0.0315949, -0.0649383, 0.0652361, 0.0959796, 0.00258569, 0.0856252, -0.0733854, -0.00866545, 0.0365236];
% Y0=[6, 1.62154, -4.27831, -2.51281, 2.56441, -3.10519, -1.93096, -4.61525, -3.47291, -5.87716, -1.67424, 1.03583, 0.722183, -0.763375, -5.54147];

%25  
% X0 = [3, 13.5397, 24.9024, 35.3358, 46.3447, 56.3002,70.1391, 83.3207, 93.4712, 105.476, 119.463, 129.286, 143.242, 153.847, 168.47, 179.253, 194.082, 208.296, 223.368, 237.006, 249.621, 261.07, 272.718, 286.88, 299.424];
% V0 = [24, 26.7708, 25.776, 27.7185, 23.9254, 27.1322, 24.1791, 26.6926, 23.2589, 23.377, 25.3875, 23.1008, 23.1951, 25.5982, 25.7415, 25.0561, 24.7091, 25.0984, 25.1019, 27.9725, 24.1589, 27.7454,27.0452, 24.7134, 27.3174];
% Y0 = [6, -0.112994, -4.44194, -0.421757, 0.221557, -2.52014, -6.13623, 1.68605, 0.957107, -3.04622, -2.5238, -5.49583, -0.00768573,-2.35797, 3.74447, 2.95601, -3.41339, 1.76657, -6.01181, 5.40895,3.47778, 2.73146, -3.44366, 4.03571, 5.77772];
% T0 = [-0.1, -0.0710873, 0.0256153, 0.0988614, -0.07731, 0.0393069, -0.0922301, -0.0232783, -0.0667084, -0.0573969, -0.0467252, -0.00416431, 0.097284, -0.0357985, -0.00377033, 0.00724916,0.0694063, -0.0791594, 0.00439009, -0.0637471, 0.0203682, 0.069423, -0.0874251, 0.0795274, 0.0426433]; 
%  
% X0=[3, 18.0854, 30.3647, 45.1365, 60.0502, 70.6654, 85.5989, 99.3615, 109.328, 121.184, 134.854, 148.74, 159.236, 173.955, 184.192];
% V0=[29, 31.8255, 29.6376, 29.9274, 28.797, 29.0066, 26.3965, 26.5839, 26.2735, 33.7142, 34.6848, 31.2041, 33.0425, 34.2009, 30.8518];
% Y0=[6, -5.95227, -0.791393, 4.42584, -1.78233, 5.88794, 5.56068, -5.48951, -3.21529, 0.0960576, 1.41438, 2.98568, 2.95328, 4.34558, -4.75859];
% T0=[-0.1, -0.0349378, 0.0438069, -0.064689, 0.0809711, 0.00371052, 0.0379575, -0.019844, 0.0300364, -0.0646064, -0.0682516, -0.00481484, -0.0952003, -0.0600973, -0.0467065];
% S0=[-93.2501, -78.1647, -65.8854, -51.1136, -36.2, -25.5847, -10.6512, 3.11138, 13.0779, 24.9341, 38.6037, 52.4901, 62.9854, 77.7048, 87.9423];

% tStart= cputime;
tic
%     [t,xPR,yPR,wPR,vPR,accPR,accyPR,H] = heuler(h,t_final,X0,Y0,T0,V0,Atol,Rtol);
    [t,xPR,yPR,wPR,vPR,accPR,accyPR,Ht] = Vheuler(h,t_final,X0,Y0,T0,V0,Atol,Rtol,model);
%     [t,xPR,yPR,wPR,vPR,accPR,accyPR] = heun(h,t_final,X0,Y0,T0,V0);
%     [t,xPR,yPR,wPR,vPR,accPR,accyPR] = Rk1(h,t_final,X0,Y0,T0,V0);
 toc
% tEnd= cputime - tStart
if model == 1
    xN=xPR; yN=yPR; wN=wPR; vN=vPR; t1=t; accN=accPR;
else
    xPR=xPR; yPR=yPR; wPR=wPR; vPR=vPR; t2=t;
end

% figure (1)
% for i=1:n
%     if i<n
%         plot(xPR(i,:),yPR(i,:),'linewidth',1.5)
%         hold on
%     else
%         plot(xPR(i,:),yPR(i,:),'linewidth',1.5)
%         title('Position')
%         hold off
%     end
% end
%  
% 
% figure (2)
% hold on
% for i=1:n
% plot(t,vPR(i,:),'linewidth',1.5)
% end
% xlabel('Time (s)')
% ylabel('Speed (m/s)')
% axis([0 t_final min(min(vPR(:,:))) max(max(vPR(:,:)))])
% hold off
% % 
% figure (3)
% hold on
% for i=1:n
% plot(t(1:end-1),accPR(i,:),'linewidth',1.5)
% end 
% xlabel('Time (s)')
% ylabel('F_i (m/s^2)') 
% hold off
% 
% figure (4)
% hold on
% for i=1:n
% plot(t(1:end -1 ),accyPR(i,:),'linewidth',1.5)
% end 
% xlabel('Time (s)')
% ylabel('u_i (m/s^2)') 
% hold off


 
% for i=1:length(t)
% tet(i)=norm(vPR(:,i)-vstar,Inf);
% end
% figure
% plot(t(1:end),tet)

% for i=1:n
%     for z=1:length(t)-1
%         latacc(i,z)=accPR(i,z)*cos(wPR(i,z))-vPR(i,z)*accyPR(i,z)*sin(wPR(i,z));
%     end
% end
% plot(t(1:end-1),latacc,'linewidth',1.5)


% 
% for i=1:n
%     for j=1:n
%         for z=1:length(t) 
%             dij(i,j,z)= dist(xPR(i,z),xPR(j,z),yPR(i,z),yPR(j,z),p);
%         end
%     end
% end
% plot(t ,squeeze(dij(1,:,:)),'linewidth',1.5)
% 
% for z=1:length(t)
%  tempmat=dij(:,:,z);
%  md(z)= min(tempmat(tempmat>0)); %minimum distance
% end
% mmd(1)=200;
% for z=1:length(t)
%     for i=1:n
%         for j=i+1:n
%             mmd(z)=min([md(z),dij(i,j,z)]);
%         end
%     end
% end
%  
% for i=1:length(t)-1
% normFp(i)=norm(accPR(:,i),Inf);
% end
%  
% for i=1:length(t)-1
% normUp(i)=norm(accyPR(:,i),Inf);
% end

% % 
% figure(5)   
% hold on
% plot(t(1:end-1),normFp,'linewidth',1.5)
% xlabel('Time (s)')
% ylabel('|F_i|_\infty') 
% hold off
% legend('P-Relativistic')
% axis([0 40 0 40])

% figure  
% hold on
% plot(t(1:end-1),normUp,'linewidth',1.5)
% xlabel('Time (s)')
% ylabel('|u_i|_\infty') 
% hold off
% legend( 'P-Relativistic')
% axis([0 40 0 0.015])

% for z = 1:length(t-1)
%     HR(z)=0;
%     for i = 1:n                                                                                 % Counter for Vehicles
%         sumv(i)=0;
%         for k = i+1:n                                                                         % Counter for other Vehicles
%             D(z,i,k) = sqrt((xPR(i,z)-xPR(k,z))^2+p*(yPR(i,z)-yPR(k,z))^2);          % Calculation of Distance
%             D(z,k,i) = D(z,i,k);
%         end
%         for k = 1:n                                                                            % Calculation of Summation of V(d(i,j))
%             if k ~=i
%                 sumv(i) = sumv(i) + V(D(z,i,k),L,lambda,q);
%             end
%         end
%         HR(z) = HR(z)+ 0.5 * ((vPR(i,z)*cos(thetaPR(i,z))-vstar)^2 + 0.5 * (vPR(i,z)*sin(thetaPR(i,z)))^2)/((vmax-vPR(i,z))*vPR(i,z))+ U(yPR(i,z),a,c) + 1/2*sumv(i) + A*(1/(cos(thetaPR(i,z))-cos(phi))-1/(1-cos(phi)));
%     end
% end
% 
% % 
% % t1=t;
% save('xr.mat','xPR')
% save('yr.mat','yPR')
% save('thetar.mat','thetaPR')
% save('vr.mat','vPR')
% save('accr.mat','accPR')
% save('accyr.mat','accyPR')
% save('t1.mat','t1')
