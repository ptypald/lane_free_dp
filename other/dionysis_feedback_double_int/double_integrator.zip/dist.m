function val = dist(s1,s2,y1,y2,p)
 

val = sqrt((s1-s2)^2+p*(y1-y2)^2);


end