function val = g2(s) 

val = s;

end